#ifndef UNTITLED1_UTILITIES_H
#define UNTITLED1_UTILITIES_H

/*Libraries inclusion*/
#include <time.h>
#include <stdlib.h>
#include <time.h>

/*Functions and procedures' signatures*/

void clearscreen (void);
void seedInit(void);
int random(int min, int max);
int trowADice (int faces);
void delay (int ms);

#endif //UNTITLED1_UTILITIES_H
